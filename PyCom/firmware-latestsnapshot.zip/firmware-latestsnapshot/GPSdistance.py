# float TinyGPS::distance_between (float lat1, float long1, float lat2, float long2) 
# {
#   // returns distance in meters between two positions, both specified 
#   // as signed decimal-degrees latitude and longitude. Uses great-circle 
#   // distance computation for hypothetical sphere of radius 6372795 meters.
#   // Because Earth is no exact sphere, rounding errors may be up to 0.5%.
#   // Courtesy of Maarten Lamers
#   float delta = radians(long1-long2);
#   float sdlong = sin(delta);
#   float cdlong = cos(delta);
#   lat1 = radians(lat1);
#   lat2 = radians(lat2);
#   float slat1 = sin(lat1);
#   float clat1 = cos(lat1);
#   float slat2 = sin(lat2);
#   float clat2 = cos(lat2);
#   delta = (clat1 * slat2) - (slat1 * clat2 * cdlong); 
#   delta = sq(delta); 
#   delta += sq(clat2 * sdlong); 
#   delta = sqrt(delta); 
#   float denom = (slat1 * slat2) + (clat1 * clat2 * cdlong); 
#   delta = atan2(delta, denom); 
#   return delta * 6372795; 
# }
# returns distance in meters between two GPS coodinates
# hypotheical sphere radius 6372795 meter
# coutesy of TinyGPS and Maarten Lamers
LAT = 0
LON = 1
def GPSdistance(gps1,gps2):
  from math import sin, cos, radians, pow, sqrt, atan2
  delta = radians(gps1[LON]-gps2[LON])
  sdlon = sin(delta)
  cdlon = cos(delta)
  lat = radians(gps1[LAT])
  slat1 = sin(lat); clat1 = cos(lat)
  lat = radians(gps2[LAT])
  slat2 = sin(lat); clat2 = cos(lat)

  delta = pow((clat1 * slat2) - (slat1 * clat2 * cdlon),2)
  delta += pow(clat2 * sdlon,2)
  delta = sqrt(delta)
  denom = (slat1 * slat2) + (clat1 * clat2 * cdlon)
  return int(round(6372795 * atan2(delta, denom)))
  
# should return 207 meter
strt = 0.0000001
for d in range(8):
  print("dist decimals %d (%.8f): %d meter" %  (7-d,strt,GPSdistance((51.419563,6.14741),(51.420473+strt,6.144795+strt))))
  strt *= 10
  
