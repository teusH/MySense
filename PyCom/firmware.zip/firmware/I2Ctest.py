# PyCom Micro Python / Python 3
# test I2C connected devices and if known try them
# Copyright 2019, Teus Hagen, GPLV4
__version__ = "0." + "$Revision: 4.4 $"[11:-2]
__license__ = 'GPLV4'

from time import sleep
from machine import I2C
pins = ('P23','P22')
#pwr = 'P21' # need to enable I2C power line
pwr = None

if pwr:
    from machine import Pin
    if not Pin(pwr, mode=Pin.OUT, pull=None, alt=-1).value():
        Pin(pwr, mode=Pin.OUT, pull=None, alt=-1).value(1)

def chip_ID(i2c, address=0x77): # I2C dev optional ID
    chip_ID_ADDR = const(0xd0)
    # Create I2C device.
    if not type(i2c) is I2C:
      raise ValueError('An I2C object is required.')
    ID = 0 # 12 bits name, 9 bits part nr, 3 bits rev
    try: ID = i2c.readfrom_mem(address, chip_ID_ADDR, 3)
    except: pass
    # print("ID: ", ID)
    return int.from_bytes( ID,'little') & 0xFF

i2c = I2C(0, I2C.MASTER, pins=pins)

print("Doing I2C bus scan")
addrs = i2c.scan()
print("Found on I2C bus: ", addrs)

for addr in addrs:
    ID = chip_ID(i2c, address=addr)
    print("Try I2C addr: 0x%X, chip ID: 0x%X" % (addr,ID))
    try:
        if (addr == 0x77) or (addr == 0x76):
          BME280_ID = const(0x60)
          BME680_ID = const(0x61)
          print("Try as BME280/680 device")
          if ID == BME680_ID:
            name = 'BME680'
            import BME_I2C as LIB
            device = LIB.BME_I2C(i2c, address=addr, debug=False, calibrate=None)
          elif ID == BME280_ID:
            name = 'BME280'
            import BME280 as LIB
            device = LIB.BME_I2C(i2c, address=addr, debug=False, calibrate=None)
          else:
            print("Unknown BME chip ID=0x%X" % ID)
            break
        elif (addr == 0x44) or (addr == 0x45):
          name = 'SHT31'
          import Adafruit_SHT31 as LIB
          device = LIB.SHT31(address=addr, i2c=i2c, calibrate=None)
        elif (addr == 0x3c):
          name = 'SSD1306'
          import SSD1306
          device = SSD1306.SSD1306_I2C(128,64,i2c,addr=addr)
        else:
          print("Unknown addr: 0x%X" % addr)
          continue
    except OSError as e:
        print("Error at addr 0x%X: %s" % (addr, e))
        i2c.init(0,pins=pins)
        sleep(1)
        continue
    except RuntimeError as e:
        print("Failure on devive driver: %s" % e)
        continue
    print("Try simple operation on device %s" % name)
    try:
        if name[:3] == 'SSD':
            print("Oled SSD1306")
            device.fill(1) ; device.show()
            sleep(1)
            device.fill(0); device.show()
        else:
            print("Meteo %s: temp: %.2f oC" % (name,device.temperature))
    except Exception as e:
        print("Device operation error: %s" % e)
