# Copyright 2019, Teus Hagen, GPLV4
# simple test to see if meteo I2C device is present
from time import sleep_ms
from machine import I2C
import sys

__version__ = "0." + "$Revision: 5.1 $"[11:-2]
__license__ = 'GPLV4'

import whichI2C

which = whichI2C.identifyI2C(identify=False, debug=True)
device = which.getIdent(names=['BME','SHT'],atype='meteo')
if not device:
  print("Unable to find meteo device")
  sys.exit()
else: print("Meteo I2C device: ", device)
nr = device['index']
i2c = device['i2c']
addr = device['address']
meteo = device['name']
pins = device['pins']

try:
  from Config import calibrate
except:
  calibrate = None

# Create library object using our Bus I2C port
try:
    if meteo == 'BME280':
      import BME280 as BME
      useMeteo = BME.BME_I2C(i2c, address=addr, debug=False, calibrate=calibrate)
    elif meteo == 'BME680':
      import BME_I2C as BME
      useMeteo = BME.BME_I2C(i2c, address=addr, debug=False, calibrate=calibrate)
    elif meteo[:3] == 'SHT':
        import Adafruit_SHT31 as SHT
        useMeteo = SHT.SHT31(address=addr, i2c=i2c, calibrate=calibrate)
    else: raise ValueError(meteo)
except ImportError:
    raise ValueError("SHT or BME library not installed")
except Exception as e:
    raise ValueError("Fatal: meteo module %s" % e)

print("Found I2C meteo device %s" % meteo)
# change this to match the location's pressure (hPa) at sea level
useMeteo.sea_level_pressure = 1024.25 # 1013.25
print("Try 5 measurements")
for cnt in range(0,5):
  try:
    print("\nTemperature: %0.1f oC" % useMeteo.temperature)
    hum = useMeteo.humidity
    print("Humidity: %0.1f %%" % hum)
    if meteo[:3] == 'BME':
        useMeteo.sea_level_pressure -= 0.5
        print("Pressure: %0.3f hPa" % useMeteo.pressure)
        print("Altitude = %0.2f meters with sea level pressure: %.2f hPa" % (useMeteo.altitude,useMeteo.sea_level_pressure))
    if meteo is 'BME680':
        if not cnt:
            try:
              from Config import M_gBase  # if present do not recalculate
              useMeteo.gas_base = M_gBase
              gBase = True
            except: useMeteo.gas_base = None # force recalculation gas base line
        if useMeteo.gas_base == None:
            gBase = False
            print("%salculating stable gas base level. Can take max 5 minutes to calculate gas base." % ('Rec' if cnt else 'C'))
        else: gBase = True
        AQI = useMeteo.AQI # first time can take a while
        if useMeteo.gas_base != None:
            print("Gas base line calculated: %.1f" % useMeteo.gas_base)
            gBase = True
        gas = useMeteo.gas
        print("Gas: %.3f Kohm" % round(gas/1000.0,2))
        if (useMeteo.gas_base != None) and (AQI != None):
            print("AQI: %0.1f %%" % AQI)
        else:
            print("Was unable to calculate AQI. Will try again.")
            print("Allow 30 secs extra sleep")
            sleep_ms(30*1000)
  except OSError as e:
    print("Got OS error: %s. Will try again." % e)
    i2c.init(I2C.MASTER,pins=pins[:2])
  finally:
    print("sleep for 60 secs")
    sleep_ms(60*1000)
sys.exit()
