# test script for GPS location sensor
# Copyright 2019, Teus Hagen MySense GPLV4

from machine import UART
from time import sleep_ms, ticks_ms

__version__ = "0." + "$Revision: 5.1 $"[11:-2]
__license__ = 'GPLV4'

# dflt pins=(Tx-pin,Rx-pin,Pwr-pin): wiring Tx-pin -> Rx GPS module
# Pwr dflt None (not switched) 3V3 DC
# default UART(port=1,baudrate=9600,timeout_chars=2,pins=('P3','P4'))

# useGPS, G_Tx, G_Rx, G_Pwr overwrite via Config, handled by whichUART
uart = [-1]
GPSpins = ('P4','P3',None)
which = None
try:
  import whichUART
  which = whichUART.identifyUART(uart=uart,debug=True)
  GPSpins = which.uartGPS['pins']
except Exception as e:
  print("Error: %s. Using GPS pin defaults." % e)
finally:
  print("GPS pins used: ", GPSpins)

if (which != None) and (not which.uartGPS['use']):
  raise OSError("GPS not configured")

print('GPS: using %s nr 1: Rx->pin %s, Tx->pin %s, Pwr->' % (which.uartGPS['name'] if which != None else 'NEO-6',GPSpins[0],GPSpins[1]),GPSpins[2])

last_read = 0
def readCR(serial):
  global last_read
  if not last_read:
    serial.readall()
    last_read = ticks_ms()
  last_read = ticks_ms()-last_read
  if last_read < 200 and last_read >= 0:
    sleep_ms(200-last_read)
  try:
    line = serial.readline().decode('utf-8')
  except:
    print('Read line error')
    line = ''
  last_read = ticks_ms()
  return line.strip()

# UART Pins pins=(Tx,Rx) default Tx=P3 and Rx=P4
try:
    print("GPS raw:")
    which.PwrTTL(GPSpins, on=True)
    ser = UART(1,baudrate=9600,timeout_chars=80,pins=GPSpins[:2])
    #ser = which.openUART('gps')
    for cnt in range(20):
       if ser.any(): break
       if cnt > 19: raise OSError("GPS not active")
       sleep_ms(200); print('.',end='')
    print("UART activated")
    for cnt in range(10):
      try:
        x=readCR(ser)
      except:
        print("Cannot read GPS data")
        break
      print(x)
      sleep_ms(200)
    # which.PwrTTL(GPSpins, on=False)
    # ser.deinit()

    print("Using GPS Dexter for location fit:")
    # which.PwrTTL(GPSpins, on=True)
    import GPS_dexter as GPS
    #gps = GPS.GROVEGPS(port=1,baud=9600,debug=False,pins=GPSpins[:2])
    gps = GPS.GROVEGPS(port=ser)
    # for cnt in range(0,20):
    #    if ser.any(): break
    #    if cnt > 19: raise OSError("GPS not active")
    #    sleep_ms(200); print('.',end='')
    # print("UART activated")
    for cnt in range(10):
      data = gps.MyGPS()
      if data:
        hours = int(float(data['timestamp']))
        days = int(float(data['date']))
        millies = int(float(data['timestamp'])*1000)%1000
        #print("Date-time: %s/%s" % (data['date'],data['timestamp']))
        print("Date %d/%d/%d, time %d:%d:%d.%d" % (2000+(days%100),(days//100)%100,days//10000,hours//10000,(hours//100)%100,hours%100,millies))
        print("lon %.6f, lat %.6f, alt %.2f m" % (data['longitude'],data['latitude'],data['altitude']))
        # print(data)
        gps.debug = False
      else:
        print('No satellites found for a fit')
        print('Turn on debugging')
        gps.debug = True
      sleep_ms(5000)

except ImportError:
    print("Missing Grove GPS libraries")
except Exception as e:
    print("Unable to get GPS data on port with pins", GPSpins, "Error: %s" % e)
which.PwrTTL(GPSpins, on=False)
ser.deinit()
#which.closeUART('gps')
import sys
sys.exit()



# raw  GPS output something like
'''
$GPGGA,001929.799,,,,,0,0,,,M,,M,,*4C
$GPGSA,A,1,,,,,,,,,,,,,,,*1E
$GPGSV,1,1,00*79
$GPRMC,001929.799,V,,,,,0.00,0.00,060180,,,N*46
$GPGGA,001930.799,,,,,0,0,,,M,,M,,*44
$GPGSA,A,1,,,,,,,,,,,,,,,*1E
'''
