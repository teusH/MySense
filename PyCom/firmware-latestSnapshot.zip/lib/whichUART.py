# identify which UART device is c nnected to which TTL connector
# Copyright 2019, Teus Hagen, GPLV4, MySense

from machine import UART
from time import sleep_ms

__version__ = "0." + "$Revision: 5.1 $"[11:-2]
__license__ = 'GPLV4'

# Config.py definitions preceed
# if UARTpins array of (Tx,Rx[,Pwr]) tuples is defined try to identify UART device
# if UARTpins is defined dust or useGPS + pins maybe overwritten
class identifyUART:
  def __init__(self, uart=1, UARTpins=[('P4','P3',None),('P11','P10',None)], identify=True, debug=False):
    self.uart = uart
    if self.uart > 2: raise OSError('No free UARTS')
    self.devs = []
    self.debug = debug

    try: from Config import UARTpins
    except: pass
    for i in 0, 1:
      for item in range(0,len(UARTpins[i])): UARTpins[i] = list(UARTpins[i])
    # dust defauls
    dust = True
    D_Tx = UARTpins[0][0]; D_Rx = UARTpins[0][1]; D_Pwr = UARTpins[0][2]
    try: from Config import dust
    except: pass
    self.dust = dust
    try: from Config import D_Tx
    except: pass
    try: from Config import D_Rx
    except: pass
    try: from Config import D_Pwr
    except: pass
    UARTpins[0][0] = D_Tx; UARTpins[0][1] = D_Rx; UARTpins[0][2] = D_Pwr
    useGPS = True # dflt
    G_Tx = UARTpins[1][0]; G_Rx = UARTpins[1][1]; G_Pwr =  UARTpins[1][2]
    try: from Config import useGPS
    except: pass
    self.useGPS = useGPS
    try: from Config import G_Tx
    except: pass
    try: from Config import G_Rx
    except: pass
    try: from Config import G_Pwr
    except: pass
    UARTpins[1][0] = G_Tx; UARTpins[1][1] = G_Rx; UARTpins[1][2] = G_Pwr

    self.UARTs = []
    for item in UARTpins:
      if len(item) < 3: item[2] = None
      # elif type(item[2]) is str: self.PwrTTL(item,on=True) # power up
      self.UARTs.append(tuple(item[:3]))
    if not len(self.UARTs):
      if self.debug: print("No UART pins defined")
    else:
      if not identify: return None
      self.devs = self.identify()
      if self.debug:
        print("UART devices: ", end='')
        for (item,sens) in self.devs.items():
           print("%s(%s) " % (item,sens['name']))
        print()
    return None

  # power on/off on TTL, return prev value
  def PwrTTL(self, pins, on=None):
    if not type(pins[2]) is str: return None
    from machine import Pin
    pin = Pin(pins[2], mode=Pin.OUT)
    if on:
      if pin.value(): return True
      if self.debug: print("Activate TTL chan (Tx,Rx,Pwr): ", pins)
      pin.value(1); sleep_ms(200); return False
    elif on == None: return pin.value()
    elif pin.value():
      if self.debug: print("Deactivate TTL chan (Tx,Rx,Pwr): ", pins)
      pin.value(0); return True
    else: return False

  def openUART(self, atype):
    if not len(self.devs): self.devs = self.identify()
    if not atype in self.devs.keys(): raise ValueError("%s: not identified" % atype)
    nr = -1
    for i in range(0,len(self.uart)):
       if not type(self.uart[i]) is dict: continue
       if self.uart[i]['type'] == atype: nr = i
    if nr < 0: raise OSError("%s: not in uarts" % atype)
    self.PwrTTL(self.devs[atype]['pins'], on=True)
    if self.devs[atype]['uart'] == None:
      self.devs[atype]['uart'] = UART(nr, baudrate=self.devs[atype]['baud'], timeout_chars=20)
    return self.devs[atype]['uart']

  def closeUART(self, atype):
    if not atype in self.devs.keys(): return False
    nr = -1
    for i in range(0,len(self.uart)):
      if not type(self.uart[i]) is dict: continue
      if self.uart[i]['type'] == atype: nr = i
    if nr < 0: return False
    self.PwrTTL(self.devs[atype]['pins'], on=False)
    if self.devs[atype]['uart'] != None:
      self.devs[atype]['uart'].deinit()
      self.devs[atype]['uart'] = None
    return True

  # enable a TTL channel and check if it is alive
  def getIdent(self, pins, baudrate=9600,pwr=None):
    data = [
      b'\x42\x4D\xE1\x00\x01\x01\x71', # PMS
      b'\xAA\xB4\x06\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF\xFF\x06\xAB', # SDS
      b'\xAA\xB4\x06\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF\xFF\x06\xAB', # SPS
      ]
    prev = self.PwrTTL(pins, on=True)
    if self.uart > 2: raise ValueError("Max UARTs reached")
    ser = UART(self.uart, baudrate=baudrate, pins=tuple(pins[:2]), timeout_chars=20)
    fnd = None
    for i in range(0,2*len(data)):
      sleep_ms(5*500)
      try: line = ser.readall()
      except:
        print("Uart read error")
        continue
      if (line == None) or (not len(line)):   # try to wake up
        activate = data[i % len(data)]
        if self.debug: print("%d: Try a wakeup, send: " % i, activate)
        ser.write(activate)
        continue
      else:
        if self.debug: print("Read: ", line)
        if line.count(b'u-blox'): fnd = 'NEO-6'
        elif line.count(b'$GPG'): fnd = 'GPS'
        elif line.count(b'\x42\x4D') or line.count(b'BM\x00\x1C'): fnd = 'PMSx003'
        elif line.count(b'\xAA') and line.count(b'\xC0'): fnd = 'SDS011'
        elif line.count(b'~\x00\xd3\x00') or line.count(b'\x00\x2C~'): fnd = 'SPS30'
        if fnd: break
    ser.readall(); ser.deinit(); del ser; self.PwrTTL(pins,on=prev)
    if fnd: return fnd,pins
    if (not pins[2]) and pwr:
      for dlf in 'P19','P20': # try dflts: P1? in V2.1
        rts = self.getIdent((pins[0],pins[1],dfl),baudrate=baudrate)
        if rts[0]: return rts
    return None, pins

  # try to discover type of uart sensor
  def identify(self):
    devs = {}
    for pins in self.UARTs:
        if self.debug: print("identifying pins: ",pins)
        if (not pins[0]) or (not pins[1]): continue
        for baud in [9600,115200]:
          if self.debug:
            print("Try UART %d baud, pins: Tx~>%s, Rx~>%s, Pwr~>%s" % (baud,pins[0],pins[1],pins[2]))
          (dev,ppins) = self.getIdent(pins, baudrate=baud, pwr=True)
          if self.debug: print("Found UART device: ", dev, ", pins: ", ppins)
          if dev == None: continue
          atype = None; use = False
          if (not 'dust' in devs.keys()) and (dev in ['PMSx003','SDS011','SPS30']):
            atype = 'dust'
            if self.dust: use = True
          elif (not 'gps' in devs.keys()) and (dev in ['NEO-6','GPS']):
            if self.useGPS: use = True
            atype = 'gps'
          if atype: # found one
            devs[atype] = { 'type': atype, 'name': dev, 'use': use,
                'fd': None, 'enabled': None,
                'pins': ppins, 'baud': baud, 'uart': None }
            if self.debug:
              print("UART(%d): %s %s on Tx~>%s, Rx~>%s, Pwr~>%s, baud %d" % (self.uart,atype,dev,ppins[0],ppins[1], ppins[2], baud))
            break
    return devs

  @property
  def uartDust(self):
    if not 'dust' in self.devs.keys(): return None
    return self.devs['dust']

  @property
  def DUST(self):
    if not 'dust' in self.devs.keys(): return None
    return self.devs['dust']['name']

  @property
  def D_TX(self):
    if not 'dust' in self.devs.keys(): return None
    return self.devs['dust']['pins'][0]

  @property
  def D_RX(self):
    if not 'dust' in self.devs.keys(): return None
    return self.devs['dust']['pins'][1]

  @property
  def D_PWR(self):
    if not 'dust' in self.devs.keys(): return None
    return self.devs['dust']['pins'][2]

  @property
  def uartGPS(self):
    if not 'gps' in self.devs.keys(): return None
    return self.devs['gps']

  @property
  def GPS(self):
    if not 'gps' in self.devs.keys(): return None
    return self.devs['gps']['name']

  @property
  def G_TX(self):
    if not 'gps' in self.devs.keys(): return None
    return self.devs['gps']['pins'][0]

  @property
  def G_RX(self):
    if not 'gps' in self.devs.keys(): return None
    return self.devs['gps']['pins'][1]

  @property
  def G_PWR(self):
    if not 'gps' in self.devs.keys(): return None
    return self.devs['gps']['pins'][2]
