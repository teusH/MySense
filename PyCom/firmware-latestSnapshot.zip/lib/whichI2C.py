# Copyright 2019, Teus Hagen, GPLV4
# search for I2C devices and get supporting libraries loaded
from time import sleep_ms
from machine import I2C

__version__ = "0." + "$Revision: 1.3 $"[11:-2]
__license__ = 'GPLV4'

# Config.py definitions preceed
# if I2Cpins array of [(SDA,SCL[,Pwr]) tuples are defined try to identify devices
class identifyI2C:
  types = { 'meteo': ['BME','SHT'], 'display': ['SSD'], 'all':['BME','SHT']+['SSD']}
  def __init__(self, i2c=[], I2Cpins=[('P23','P22',None)], identify=True, debug=False):
    try: from Config import I2Cpins
    except: pass
    for i in range(0,len(I2Cpins)):
      if len(I2Cpins[i]) < 3:
        I2Cpins[i] = tuple(list(I2Cpins[i])+[None])
    I2Cdevices = [
            ('BME280',0x76),('BME280',0x77), # BME serie Bosch
            ('SHT31',0x44),('SHT31',0x45),   # Sensirion serie
            ('SSD1306',0x3c)                 # oled display
       ]
    try: from Config import I2Cdevices
    except: pass
    self.I2Cdevices = I2Cdevices
    self.I2Cpins = I2Cpins
    self.debug = debug
    # self.I2Cs = []
    self.devs = {}
    if not identify: return None
    self.devs = self.identify()
    if self.debug:
      for item in self.devs.keys():
        print("I2C %s device: " % item, self.devs[item])
    return None

  # power on/off on TTL, return prev value
  def PwrI2C(self, pins, i2c=None, on=None):
    if not type(pins[2]) is str: return None
    from machine import Pin
    pin = Pin(pins[2], mode=Pin.OUT)
    if on:
      if pin.value(): return True
      if self.debug: print("Activate I2C chan (Tx,Rx,Pwr): ", pins)
      pin.value(1)
      if i2c:
        i2c.init(I2C.MASTER, pins=tuple(pins[:2]))
        sleep_ms(200)
      return False
    elif on == None: return pin.value()
    elif pin.value():
      if self.debug: print("Deactivate I2C chan (Tx,Rx,Pwr): ", pins)
      pin.value(0); return True
    else: return False

  # obtain I2C dev optional ID
  def chip_ID(self, pins, i2c=None, address=0x77):
    if i2c == None: return None
    chip_ID_ADDR = const(0xd0)
    # Create I2C device.
    if not type(i2c) is I2C:
      raise ValueError('An I2C object is required.')
    ID = 0 # 12 bits name, 9 bits part nr, 3 bits rev
    prev = None
    if type(pins[2]) is str:
        prev = self.PwrI2C(pins,on=True)
        sleep_ms(200)
    try:
        ID = i2c.readfrom_mem(address, chip_ID_ADDR, 3)
    except Exception as e:
        print("Unable to read I2C chip ID: %s" % e)
    if prev != None: self.PwrI2C(pins,on=prev)
    # print("ID: ", ID)
    return int.from_bytes( ID,'little') & 0xFF

  BME280_ID = const(0x60)
  BME680_ID = const(0x61)
  SSD1306_ID = const(0x3)

  # side effect will enable power, on end: power dflt enabled
  def getIdent(self, names=types['all'],atype='none',power=True):
    if self.debug:
      print("Using I2C SDA/SCL/Pwr pins: ", self.I2Cpins)
      print("Search for I2C meteo devices", self.I2Cdevices)
      # print("Wrong wiring may hang I2C address scan search...")
    for index in range(0,len(self.I2Cpins)):
      cur_i2c = I2C(index, I2C.MASTER, pins=self.I2Cpins[index][:2]) # master
      previous = self.PwrI2C(self.I2Cpins[index], cur_i2c, on=True)
      regs = cur_i2c.scan(); sleep_ms(200)
      for item in self.I2Cdevices:
        if type(item) is tuple: item = list(item)
        if item[1] in regs:
          ID = self.chip_ID(self.I2Cpins[index], cur_i2c, item[1])
          if item[0][:3] == 'BME':
            if ID == BME680_ID: item[0] = 'BME680'
            elif ID != BME280_ID: raise ValueError("Unknown BME id 0x%X" % ID)
          if self.debug:
            print('%s ID=0x%X I2C[%d]:' % (item[0],ID,index), ' SDA~>%s, SCL~>%s, Pwr->' % self.I2Cpins[index][:2], self.I2Cpins[index][2], ', reg 0x%2X' % item[1])
          dev = { 'name': item[0], 'use': None, 'fd': None, 'enabled': None,
                  'pins': self.I2Cpins[index], 'address': item[1],
                  'index': index, 'i2c': cur_i2c}
          if not item[0][:3] in names: continue
          if not atype in self.devs.keys():
            self.devs[atype] =  dev
          else:
            fnd = False
            a = self.devs[atype] if type(self.devs[atype]) is list else [self.devs[atype]]
            for one in a:
              if (one['index'] == index) and (one['address'] == item[1]):
                fnd = True; break
            if fnd: continue
            self.devs[atype] = a + [dev]
          if item[0][:3] in names:
            dev['use'] = True
            if item[0][:3] == 'SSD':
                try:
                  from Config import useSSD
                  if not useSSD: dev['use'] = False
                except: pass
      self.PwrI2C(self.I2Cpins[index], cur_i2c, on=power)
    return self.devs[atype]

  # search I2C for sensor types
  def identify(self,types=types):
    for atype in types:
      if atype == 'all': continue
      if not atype in self.devs.keys():
        self.getIdent(names=types[atype], atype=atype)
    # devs['oled'] = devs['display']
    return self.devs

  def i2cType(self,atype='meteo'):
    if not atype in self.devs.keys():
      return self.getIdent(names=types[atype],atype=atype,power=True)
    return self.devs[atype]

  def i2cPins(self,atype='meteo'):
    if not atype in self.devs.keys():
      return self.getIdent(names=types[atype],atype=atype,power=True)['pins']
    return self.devs[atype]['pins']

  def TYPE(self,atype='meteo'):
    if not atype in self.devs.keys():
      return self.getIdent(names=types[atype],atype=atype,power=True)['name']
    return self.devs[atype]['name']

  @property
  def i2cMeteo(self): return self.i2cType(atype='meteo')

  @property
  def METEO(self): return self.TYPE(atype='meteo')

  @property
  def i2cDisplay(self): return self.i2cType(atype='display')

  @property
  def i2cOled(self): return self.i2cType(atype='display')

  @property
  def DISPLAY(self): return self.TYPE(atype='display')

  @property
  def OLED(self): return self.DISPLAY()
