# simple test script for dust sensors
# Copyright 2019, Teus Hagen MySense GPLV4

# standalone test loop

__version__ = "0." + "$Revision: 5.2 $"[11:-2]
__license__ = 'GPLV4'

from time import time, sleep_ms

# dflt pins=(Tx-pin,Rx-pin,Pwr-pin): wiring Tx-pin -> Rx dust module
# Pwr dflt None (not switched) 5V DC
# default UART(port=1,baudrate=9600,timeout_chars=2,pins=('P11','P10'))

# useGPS, (Tx,Rx{,None/Pwr}) overwrite via Config, handled by whichUART
UARTpins = [('P11','P10','P20')] # dflt V2 PCB
try:
  from Config import UARTpins
except: pass
which = None
try:
  import whichUART
  which = whichUART.identifyUART(UARTpins=UARTpins,debug=True)
  DUSTpins = which.uartDust['pins']
except Exception as e:
  print("Error: %s." % e)
  import sys
  sys.exit()
finally:
  print("DUST pins used: ", DUSTpins)

if not which.uartDust['use']:
  raise OSError("DUST not configured")

dust = which.uartDust['name']
baud =  which.uartDust['baud']
print('DUST: using %s nr 1, %d baud: Rx->pin %s, Tx->pin %s, Pwr->' % (dust,baud,DUSTpins[0],DUSTpins[1]),DUSTpins[2])

try:
  if dust[:3] == 'SDS':
    from SDS011 import SDS011 as senseDust
  elif dust[:3] == 'PMS':
    from PMSx003 import PMSx003 as senseDust
  elif dust[:3] == 'SPS':
    from SPS30 import SPS30 as sensedust
  else: raise OSError("Unknown dust sensor %s" % dust)
except Exception as e:
  raise OSError("Error with %s: %s" % (dust,e))

sampling = 60    # each sampling time take average of values
interval = 5*60  # take very 5 minutes a sample over 60 seconds

Dexplicit = False
try: from Config import Dexplicit
except: pass
try:
  from Config import calibrate
except:
  calibrate = None

which.PwrTTL(DUSTpins, on=True)
from machine import UART
print("Baudrate: %d" % baud)
ser = UART(1,baudrate=baud,timeout_chars=80,pins=DUSTpins[:2])
#ser = which.openUART('dust')
sensor = senseDust(port=ser, debug=True, sample=sampling, interval=0, pins=DUSTpins[:2], calibrate=calibrate, explicit=Dexplicit)

print("Dust: using sensor %s, UART 1, " % dust, "Rx~>%s, Tx~>%s, Pwr~>%s" % DUSTpins)
print("Dust module sampling %d secs, interval of measurement %d minutes" % (sampling, interval/60))
print("PM pcs (count) values: %s pcs " %(">PMn (a la Plantower)" if Dexplicit else "<PMn (a la Sensirion)")) 

if sensor and (sensor.mode != sensor.NORMAL): sensor.Normal()
errors = 0
max = 6
for cnt in range(max):
    timings = time()
    try:
      # sensor.GoActive() # fan on wait 60 secs
      data = sensor.getData()
    except Exception as e:
      print("%s read error raised as: %s" % (dust,e))
      if errors > 20: break
      errors += 1
      sleep_ms(30*1000)
      sensor.ser.readall()
      continue
    errors = 0
    print("%s record:" % dust)
    print(data)
    timings = interval -(time()-timings)
    if timings > 0:
        print("Sleep now for %d secs with %s Off" % (timings, 'power On and fan' if cnt < (max/2) else 'fan controlled by power'))
        try:
            if cnt < (max/2): sensor.Standby()
            else: which.PwrTTL(DUSTpins, on=False)
            if timings > 60: sleep_ms((timings-60)*1000)
            print("Dust sensor start up")
            if cnt >= (max/2):
                which.PwrTTL(DUSTpins, on=True)
                sleep_ms(200)
            sensor.Normal() # fan on measuring
            sleep_ms(30*1000) # fan start up
            sensor.mode = 0 # active
        except:
            errors += 1
            sleep_ms(60*1000)
which.PwrTTL(DUSTpins, on=False)
ser.deinit()
#which.closeUART('dust')
import sys
sys.exit()
