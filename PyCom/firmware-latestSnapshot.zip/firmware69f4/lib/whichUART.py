# identify which UART device is c nnected to which TTL connector
# Copyright 2019, Teus Hagen, GPLV4, MySense

from machine import UART
from time import sleep_ms

__version__ = "0." + "$Revision: 5.1 $"[11:-2]
__license__ = 'GPLV4'

# Config.py definitions preceed
# if UARTpins array of (Tx,Rx[,Pwr]) tuples is defined try to identify UART device
# if UARTpins is defined dust or useGPS + pins maybe overwritten
# uart is free uart to do the search
class identifyUART:
  def __init__(self, uart=1, UARTpins=[('P4','P3',None),('P11','P10',None)], identify=['gps','dust'], debug=False):
    self.uart = uart
    if uart > 2: raise OSError('No free UARTS')
    self.devs = {}
    self.debug = debug
    self.types = ['gps','dust'] # configured

    try: from Config import UARTpins # [(pin dev Tx, pin dev Rx{, None or pin Pwr}),...] 
    except: pass
    for i in 0, 1:
      for item in range(0,len(UARTpins[i])): UARTpins[i] = list(UARTpins[i])
    # dflt dust = True pin, row[0][]
    dust = True
    try: from Config import dust
    except: pass
    self.dust = dust
    # deflt GPS = True, row[1][]
    useGPS = True # dflt
    try: from Config import useGPS
    except: pass
    self.useGPS = useGPS

    self.UARTs = []; fnd = False
    for item in UARTpins:
      if item[0] == 'P1': fnd = True # dflt
      if len(item) < 3: item[2] = None
      # elif type(item[2]) is str: self.PwrTTL(item,on=True) # power up
      self.UARTs.append(tuple(item[:3]))
    if not fnd: self.UARTs.insert(0,None) # omit channel 0
    if not len(self.UARTs):
      if self.debug: print("No UART pins defined")
    else:
      if not identify: return None
      self.identify(atype=identify) # where is what
      if self.debug:
        print("UART devices: ", end='')
        if self.devs:
          for (item,sens) in self.devs.items():
            print("%s(%s) " % (item,sens['name']))
        print()
    return None

  # power on/off on TTL, return prev value
  def PwrTTL(self, pins, on=None):
    if not type(pins[2]) is str: return None
    from machine import Pin
    pin = Pin(pins[2], mode=Pin.OUT)
    if on:
      if pin.value(): return True
      if self.debug: print("Activate TTL chan (Tx,Rx,Pwr): ", pins)
      pin.value(1); sleep_ms(200); return False
    elif on == None: return pin.value()
    elif pin.value():
      if self.debug: print("Deactivate TTL chan (Tx,Rx,Pwr): ", pins)
      pin.value(0); return True
    else: return False

  # unclear next fie does not seem to work
  def openUART(self, atype='dust'):
    if not atype in self.devs.keys(): self.identify(atype=atype)
    if not atype in self.devs.keys(): raise ValueError("%s: not identified" % atype)
    nr = -1
    for i in range(0,len(self.UARTs)):
       if self.UARTs[i] == self.devs[atype]['pins']: nr = i
    if not (0 <= nr <= 2): raise OSError("%s: not in available uarts" % atype)
    self.PwrTTL(self.devs[atype]['pins'], on=True)
    if self.devs[atype]['uart'] == None:
      self.devs[atype]['uart'] = UART(nr, baudrate=self.devs[atype]['baud'], timeout_chars=20)
    return self.devs[atype]['uart']

  def closeUART(self, atype='dust'):
    if not atype in self.devs.keys(): return False
    nr = -1
    for i in range(0,len(self.uart)):
      if not type(self.uart[i]) is dict: continue
      if self.uart[i]['type'] == atype: nr = i
    if nr < 0: return False
    self.PwrTTL(self.devs[atype]['pins'], on=False)
    if self.devs[atype]['uart'] != None:
      self.devs[atype]['uart'].deinit()
      self.devs[atype]['uart'] = None
    return True

  # enable a TTL channel and check if it is alive, guess where is what
  def getIdent(self, atype, pins, baudrate=9600,pwr=None):
    data = [
      b'\x42\x4D\xE1\x00\x01\x01\x71',     # PMS
      b'\x7E\x00\x00\x02\x01\x03\xF9\x7E', # SPS start
      b'\xAA\xB4\x06\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF\xFF\x06\xAB', # SDS
      ]
    prev = self.PwrTTL(pins, on=True)
    if self.uart > 2: raise ValueError("Max UARTs reached")
    if self.debug: print("Try uart (baud=%d) pins: " % baudrate, pins)
    ser = UART(self.uart, baudrate=baudrate, pins=tuple(pins[:2]), timeout_chars=20)
    fnd = None
    if self.debug: print("getIdent type %s" % atype)
    for i in range(0,2*len(data)):
      sleep_ms(5*500 if atype == 'dust' else 500)
      try:
        line = ser.readall()
        # if self.debug: print("Read: ", line)
      except:
        print("Uart read error")
        continue
      if (atype == 'dust') and ((line == None) or (not len(line))):   # try to wake up
        activate = data[i % len(data)]
        if self.debug: print("%d: Try a wakeup, send: " % i, activate)
        ser.write(activate)
        continue
      else:
        if not line: continue
        if line.count(b'u-blox'): fnd = 'NEO-6'
        elif line.count(b'$GPG'): fnd = 'GPS'
        elif line.count(b'\x42\x4D') or line.count(b'BM\x00\x1C'): fnd = 'PMSx003'
        elif line.count(b'\xAA') and line.count(b'\xC0'): fnd = 'SDS011'
        elif line.count(b'~\x00\x00') or line.count(b'\x00\xFF~'): fnd = 'SPS30'
        if fnd: break
    ser.readall(); ser.deinit(); del ser; self.PwrTTL(pins,on=prev)
    if fnd: return fnd,pins
    if (not pins[2]) and pwr:
      for dlf in 'P19','P20': # try dflts: P1? in V2.1
        rts = self.getIdent(atype,(pins[0],pins[1],dlf),baudrate=baudrate)
        if rts[0]: return rts
    return None, pins

  # try to discover types of sensors on uart (dflt all)
  def identify(self,atype=None):
    collected = []
    if not atype: atype = self.types # dflts
    doTypes = atype if type(atype) is list else [atype]
    for pins in self.UARTs:
      if not pins: continue
      if self.debug:
        print("For pins: Tx~>%s, Rx~>%s, Pwr~>%s" % pins[:3])
      for thisType in doTypes:
        if thisType in collected: continue
        if self.debug:
            print("\tTry for type %s" % thisType)
        if (thisType in self.devs.keys()) and ('pins' in self.devs[thisType].keys()):
          if len(doTypes) == 1:
            if self.debug: print("found baud %d" % self.devs[thisType]['baud'])
            return self.devs[thisType]
          else: continue
        if (not pins[0]) or (not pins[1]): continue
        dev = None
        for baud in [9600,115200]:
          if self.debug:
            print("Try UART %d baud, pins: Tx~>%s, Rx~>%s, Pwr~>%s" % (baud,pins[0],pins[1],pins[2]))
          (dev,ppins) = self.getIdent(thisType, pins, baudrate=baud, pwr=True)
          if dev: break
        if not dev: continue
        if self.debug: print("Found UART device: ", dev, ", pins: ", ppins)
        fnd = None; use = False
        if (not 'dust' in self.devs.keys()) and (dev in ['PMSx003','SDS011','SPS30']):
          fnd = 'dust'
          if self.dust: use = True
        elif (not 'gps' in self.devs.keys()) and (dev in ['NEO-6','GPS']):
          if self.useGPS: use = True
          fnd = 'gps'
        if fnd: # found one
          self.devs[fnd] = { 'type': fnd, 'name': dev, 'use': use,
              'fd': None, 'enabled': None,
              'pins': ppins, 'baud': baud, 'uart': None }
          if self.debug:
            print("found baud %d" % self.devs[fnd]['baud'])
          if (len(doTypes) == 1) and (fnd == doTypes[0]): return self.devs[fnd]
          collected.append(fnd)
          break
    return None

  def uartType(self,atype='dust'):
    if not atype in self.devs.keys(): self.identify(atype=atype)
    if atype in self.devs.keys(): return self.devs[atype]
    return None

  def uartPins(self, atype='dust'):
    if not atype in self.devs.keys(): self.identify(atype=atype)
    if atype in self.devs.keys(): return self.devs[atype]['pins']
    return None

  def TYPE(self, atype='dust'):
    if not atype in self.devs.keys(): self.identify(atype=atype)
    if atype in self.devs.keys(): return self.devs[atype]['name']
    return None

  @property
  def uartDust(self): return self.uartType(atype='dust')

  @property
  def DUST(self): return self.TYPE('dust')

  @property
  def uartGPS(self): return self.uartType(atype='gps')

  @property
  def GPS(self): return self.TYPE('gps')
