# Copyright 2019, Teus Hagen, GPLV4
# simple test to see if display I2C device is present
from time import sleep_ms
from machine import I2C
import sys

__version__ = "0." + "$Revision: 5.2 $"[11:-2]
__license__ = 'GPLV4'

useSSD = 'I2C'
try: from Config import useSSD
except: pass

if useSSD == 'I2C':
  device = None
  try:
    import whichI2C
    which = whichI2C.identifyI2C(identify=False, debug=True)
    which.getIdent(names=['SSD'],atype='display')
    device = which.devs['display']
    print("Display I2C device: ", device)
    useSSD = False if not device['use'] else 'I2C'
  except Exception as e:
    print("Unable to find meteo device")
    print("Error: %s" % e)
    sys.exit()

oled = None
if useSSD:
  try:
    try: import SSD1306
    except: raise ImportError("library SSD1306 missing")
    width = 128; height = 64  # display sizes
    if useSSD == 'I2C': # display may flicker on reload
      if (not device) or (not device['address']):
        raise ValueError("No I2C oled display found.")
      print("Found I2C[%d] device %s" % (device['index'],device['name']))
      oled = SSD1306.SSD1306_I2C(width,height,device['i2c'],addr=device['address'])
    elif useSSD == 'SPI': # for fast display
      try:
        from Config import S_CLKI, S_MOSI, S_MISO  # SPI pins config
      except:
        S_DC = 'P10'; S_MOSI = 'P11'; S_MISO = 'P14'  # SSD defaults
      try:
        from Config import S_DC, S_RES, S_CS      # GPIO SSD pins
      except:
        S_DC = 'P5'; S_RES = 'P6'; S_CS = 'P7'    # SSD default pins
      from machine import SPI
      print('Oled SPI: DC ~> %s, CS ~> %s, RST ~> %s, D1/MOSI ~> %s, D0/CLK ~> %s' % (S_DC,S_CS,S_RES,S_MOSI,S_CLKI))
      spi = SPI(0,SPI.MASTER, baudrate=100000,pins=(S_CLKI, S_MOSI, S_MISO))
      oled = SSD1306.SSD1306_SPI(width,height,spi,S_DC, S_RES, S_CS)
    else:
      oled = None
      print("Incorrect display bus %s" % useSSD)
    if oled:
      oled.fill(1) ; oled.show(); sleep_ms(1000)
      oled.fill(0); oled.show()
  except Exception as e:
    oled = None
    print('Oled display failed: %s' % e)
    import sys
    sys.exit()

# found oled, try it and blow RGB led wissle
from machine import unique_id
from machine import Pin
import binascii
try:
  from led import LED
except:
  raise OSError("Install library led")

import pycom

def sleep(secs):
    sleep_ms(int(secs*1000.0))

#button = Pin('P10',mode=Pin.IN, pull=Pin.PULL_UP)
#led = Pin('P9',mode=Pin.OUT)
#
#def pressed(what):
#  # global LED
#  print("Pressed %s" % what)
#  # LED.blink(5,0.1,0xff0000,False)
#
#  global led
#  led.toggle()
#
#button.callback(Pin.IRQ_FALLING|Pin.IRQ_HIGH_LEVEL,handler=pressed,arg='STOP')

def display(txt,x,y,clear, prt=True):
  ''' Display Text on OLED '''
  global oled
  if oled:
    if clear:
      oled.fill(0)
    oled.text(txt,x,y)
    oled.show()
  if prt:
    print(txt)

def rectangle(x,y,w,h,col=1):
  global oled
  if not oled: return
  ex = int(x+w); ey = int(y+h)
  for xi in range(int(x),ex):
    for yi in range(int(y),ey):
      oled.pixel(xi,yi,col)

def ProgressBar(x,y,width,height,secs,blink=0,slp=1):
  global oled, LED
  rectangle(x,y,width,height)
  if (height > 4) and (width > 4):
    rectangle(x+1,y+1,width-2,height-2,0)
    x += 2; width -= 4;
    y += 2; height -= 4
  elif width > 4:
    rectangle(x+1,y,width-2,height,0)
    x += 2; width -= 4;
  else:
    rectangle(x,y,width,height,0)
  step = width/(secs/slp); xe = x+width; myslp = slp
  if blink: myslp -= (0.1+0.1)
  for sec in range(int(secs/slp+0.5)):
    if blink:
      LED.blink(1,0.1,blink,False)
    sleep(myslp)
    if x > xe: continue
    rectangle(x,y,step,height)
    if oled: oled.show()
    x += step
  return True

try:
    # Turn off hearbeat LED
    pycom.heartbeat(False)
    display('test bar',0,0,True)
    if not ProgressBar(0,34,128,8,12,0xebcf5b,1):
        LED.blink(5,0.3,0xff0000,True)
    else: LED.blink(5,0.3,0x00ff00,False)
    display("MySense PyCom",0,0,True)
    myID = binascii.hexlify(unique_id()).decode('utf-8')
    display("s/n " + myID, 0, 16, False)
except Exception as e:
    print("Failure: %s" % e)
print("DONE. Soft reset.")
sys.exit()
